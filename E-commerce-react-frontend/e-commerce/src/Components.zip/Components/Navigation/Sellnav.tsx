import 'bootstrap/dist/css/bootstrap.css';
import '../../assets/Sellnav.css';

const Sellnavbar =() =>{

    return(
        <>
        <nav className="navbar sticky-top navbar-expand-lg">
        <div className="navbar-nav container-fluid">
        <div id="name">
        <b className="brand_name">BYTE<br/> MART</b>
        </div>
        <p>Seller Portal</p>
        </div>
        </nav>
        </>
    )
}

export default Sellnavbar;